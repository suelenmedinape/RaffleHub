-- Inserir produtor
INSERT INTO tb_principal (id, email, name, password, role) VALUES (1, 'adm@email.com', 'Claudio Oliveira', '$2a$10$gNNzbIzg4ruJ4AtLc5ztHuaYz8J9e8ieSlFUcqE0lDR3YGaCSLGBe', 'ROLE_ADMIN');
INSERT INTO tb_secundario (id, email, name, password, role) VALUES (1, 'ana@email.com', 'Ana Paula', '$2a$10$gNNzbIzg4ruJ4AtLc5ztHuaYz8J9e8ieSlFUcqE0lDR3YGaCSLGBe', 'ROLE_CLIENT');