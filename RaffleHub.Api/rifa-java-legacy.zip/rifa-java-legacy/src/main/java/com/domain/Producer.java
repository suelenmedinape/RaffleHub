package com.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "tb_principal")
public class Producer extends Person{

	private static final long serialVersionUID = 1L;
	
	public Producer() {
		
	}

}
