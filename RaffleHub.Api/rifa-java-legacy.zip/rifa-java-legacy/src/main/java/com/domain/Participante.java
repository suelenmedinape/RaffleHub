package com.domain;

import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "tb_participante")
public class Participante {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	private String nomeParticipante;
  	private String telefone;

    @ElementCollection
    private List<Integer> numerosEscolhidos;

    @ManyToOne
    @JoinColumn(name = "rifa_id")
    private Rifa rifa;
    
    public Participante() {
		super();
	}
}
