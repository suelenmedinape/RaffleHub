package com.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "tb_secundario")
public class Client extends Person{

	private static final long serialVersionUID = 1L;

	public Client() {
		super();
	}


}
