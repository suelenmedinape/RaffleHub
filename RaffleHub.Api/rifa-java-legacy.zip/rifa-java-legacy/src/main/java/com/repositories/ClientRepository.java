package com.repositories;

import com.domain.Client;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepository extends JpaRepository<Client, Long>{

	Client findByEmail(String email);
}
