package com.repositories;

import java.util.List;
import java.util.Optional;

import com.domain.Participante;
import com.dto.ParticipanteDTO;
import org.springframework.data.jpa.repository.JpaRepository;

import com.domain.Rifa;

public interface ParticipanteRepository extends JpaRepository<Participante, Long>{
    List<Participante> findByRifaId(Long rifaId);

    Optional<Participante> findById(Long id);

    List<Participante> findByRifaIdAndNomeParticipanteContainingIgnoreCaseOrderByNomeParticipanteAsc(Long rifaId, String nomeParticipante);

    Optional<Participante> findByRifaIdAndTelefone(Long rifaId, String telefone);


}
