package com.repositories;

import com.domain.Producer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProducerRepository extends JpaRepository<Producer, Long>{

	Producer findByEmail(String email);
}
