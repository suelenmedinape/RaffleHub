package com.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.domain.Rifa;

public interface RifaRepository extends JpaRepository<Rifa, Long>{

	Rifa findByNomeRifa(String nomeRifa);
}
