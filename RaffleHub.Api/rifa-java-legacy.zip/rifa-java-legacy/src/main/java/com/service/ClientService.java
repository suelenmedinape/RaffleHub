package com.service;

import com.domain.Client;
import com.enums.Role;
import com.repositories.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClientService {

	@Autowired
	private ClientRepository clientRepository;

	public Client findByEmail(String email) {
		return clientRepository.findByEmail(email);
	}
}
