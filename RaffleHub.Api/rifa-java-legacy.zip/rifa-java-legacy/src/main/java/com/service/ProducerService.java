package com.service;

import com.domain.Producer;
import com.repositories.ProducerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProducerService {

	@Autowired
	private ProducerRepository producerRepository;
	
	public Producer findByEmail(String email) {
		return producerRepository.findByEmail(email);
	}
}
