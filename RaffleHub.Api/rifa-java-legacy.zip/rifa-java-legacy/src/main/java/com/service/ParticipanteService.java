package com.service;

import com.domain.Participante;
import com.domain.Rifa;
import com.dto.ParticipanteDTO;
import com.dto.ParticipanteListaDTO;
import com.exceptions.ParticipanteException;
import com.exceptions.ParticipanteValidacaoException;
import com.exceptions.RifaNotFoundException;
import com.repositories.ParticipanteRepository;
import com.repositories.RifaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class ParticipanteService {

    @Autowired
    private ParticipanteRepository participanteRepository;

    @Autowired
    private RifaRepository rifaRepository;

    public Participante insert(ParticipanteDTO dto) {
        Map<String, List<String>> errors = new HashMap<>();

        Rifa rifa = rifaRepository.findById(dto.getRifaId())
                .orElseThrow(() -> new RifaNotFoundException("Rifa não encontrada"));

        List<Participante> participantes = participanteRepository.findByRifaId(dto.getRifaId());

        boolean telefoneExiste = participantes.stream()
                .anyMatch(p -> p.getTelefone().equals(dto.getTelefone()));
        if (telefoneExiste) {
            errors.computeIfAbsent("telefone", k -> new ArrayList<>())
                    .add("Telefone já cadastrado para esta rifa.");
        }

        Set<Integer> numerosUnicos = new HashSet<>(dto.getNumerosEscolhidos());
        if (numerosUnicos.size() != dto.getNumerosEscolhidos().size()) {
            errors.computeIfAbsent("numerosEscolhidos", k -> new ArrayList<>())
                    .add("Números escolhidos não podem ser repetidos.");
        }

        Set<Integer> numerosJaEscolhidos = participantes.stream()
                .flatMap(p -> p.getNumerosEscolhidos().stream())
                .collect(Collectors.toSet());
        for (Integer numero : dto.getNumerosEscolhidos()) {
            if (numerosJaEscolhidos.contains(numero)) {
                errors.computeIfAbsent("numerosEscolhidos", k -> new ArrayList<>())
                        .add("O número " + numero + " já foi escolhido por outro participante.");
            }
        }

        boolean numeroInvalido = dto.getNumerosEscolhidos()
                .stream()
                .anyMatch(n -> n < 1 || n > rifa.getQdtRifas());
        if (numeroInvalido) {
            errors.computeIfAbsent("numerosEscolhidos", k -> new ArrayList<>())
                    .add("Existem números escolhidos fora do intervalo permitido (1 até " + rifa.getQdtRifas() + ")");
        }

        if (!errors.isEmpty()) {
            throw new ParticipanteValidacaoException(errors);
        }

        Participante participante = new Participante();
        participante.setNomeParticipante(dto.getNomeParticipante());
        participante.setTelefone(dto.getTelefone());
        participante.setNumerosEscolhidos(dto.getNumerosEscolhidos());
        participante.setRifa(rifa);

        return participanteRepository.save(participante);
    }


    public List<Participante> listarParticipantesPorRifa(Long rifaId) {
        return participanteRepository.findByRifaId(rifaId);
    }

    public List<Integer> numerosDisponiveis(Long rifaId) {
        Rifa rifa = rifaRepository.findById(rifaId)
                .orElseThrow(() -> new RifaNotFoundException("Rifa não encontrada"));

        int quantidade = rifa.getQdtRifas();

        List<Integer> todosNumeros = IntStream.rangeClosed(1, quantidade)
                .boxed()
                .collect(Collectors.toList());

        List<Participante> participantes = participanteRepository.findByRifaId(rifaId);

        Set<Integer> numerosEscolhidos = participantes.stream()
                .flatMap(p -> p.getNumerosEscolhidos().stream())
                .collect(Collectors.toSet());

        todosNumeros.removeAll(numerosEscolhidos);

        return todosNumeros;
    }

    public ParticipanteListaDTO buscarPorTelefoneNaRifa(Long rifaId, String telefone) {
        Participante participante = participanteRepository
                .findByRifaIdAndTelefone(rifaId, telefone)
                .orElseThrow(() -> new ParticipanteException("Participante não encontrado nesta rifa."));

        return new ParticipanteListaDTO(participante);
    }


    public List<ParticipanteListaDTO> buscarPorNomeNaRifa(Long rifaId, String nome) {
        List<Participante> participantes = participanteRepository
                .findByRifaIdAndNomeParticipanteContainingIgnoreCaseOrderByNomeParticipanteAsc(rifaId, nome.trim());

        return participantes.stream()
                .map(ParticipanteListaDTO::new)
                .toList();
    }

    public Participante atualizar(Long id, ParticipanteDTO dto) {
        Participante participanteExistente = participanteRepository.findById(id)
                .orElseThrow(() -> new ParticipanteException("Participante não encontrado."));

        Rifa rifa = rifaRepository.findById(dto.getRifaId())
                .orElseThrow(() -> new RifaNotFoundException("Rifa não encontrada"));

        List<Participante> participantesDaRifa = participanteRepository.findByRifaId(dto.getRifaId());

        Map<String, List<String>> errors = new HashMap<>();

        boolean telefoneUsadoPorOutro = participantesDaRifa.stream()
                .anyMatch(p -> !p.getId().equals(id) && p.getTelefone().equals(dto.getTelefone()));
        if (telefoneUsadoPorOutro) {
            errors.computeIfAbsent("telefone", k -> new ArrayList<>())
                    .add("Telefone já cadastrado para esta rifa.");
        }

        Set<Integer> numerosUnicos = new HashSet<>(dto.getNumerosEscolhidos());
        if (numerosUnicos.size() != dto.getNumerosEscolhidos().size()) {
            errors.computeIfAbsent("numerosEscolhidos", k -> new ArrayList<>())
                    .add("Números escolhidos não podem ser repetidos.");
        }

        Set<Integer> numerosJaEscolhidos = participantesDaRifa.stream()
                .filter(p -> !p.getId().equals(id))
                .flatMap(p -> p.getNumerosEscolhidos().stream())
                .collect(Collectors.toSet());

        for (Integer numero : dto.getNumerosEscolhidos()) {
            if (numerosJaEscolhidos.contains(numero)) {
                errors.computeIfAbsent("numerosEscolhidos", k -> new ArrayList<>())
                        .add("O número " + numero + " já foi escolhido por outro participante.");
            }
        }

        boolean numeroInvalido = dto.getNumerosEscolhidos().stream()
                .anyMatch(n -> n < 1 || n > rifa.getQdtRifas());
        if (numeroInvalido) {
            errors.computeIfAbsent("numerosEscolhidos", k -> new ArrayList<>())
                    .add("Existem números escolhidos fora do intervalo permitido (1 até " + rifa.getQdtRifas() + ")");
        }

        if (!errors.isEmpty()) {
            throw new ParticipanteValidacaoException(errors);
        }

        participanteExistente.setNomeParticipante(dto.getNomeParticipante());
        participanteExistente.setTelefone(dto.getTelefone());
        participanteExistente.setNumerosEscolhidos(dto.getNumerosEscolhidos());
        participanteExistente.setRifa(rifa);

        return participanteRepository.save(participanteExistente);
    }

    public void deletar(Long id) {
        Participante participante = participanteRepository.findById(id)
                .orElseThrow(() -> new ParticipanteException("Participante não encontrado."));

        participanteRepository.delete(participante);
    }
}
