package com.service;

import com.domain.Participante;
import com.dto.RifaDTO;
import com.dto.RifaNomesDTO;
import com.dto.RifaUpdateDTO;
import com.exceptions.RifaAlreadyInsertException;
import com.exceptions.RifaNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.domain.Rifa;
import com.repositories.ParticipanteRepository;
import com.repositories.RifaRepository;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class RifaService {

	@Autowired
	private RifaRepository rifaRepository;
	
	@Autowired
	private ParticipanteRepository participanteRepository;

	public Rifa insert(Rifa rifa) {
		if (rifaRepository.findByNomeRifa(rifa.getNomeRifa()) != null) {
			throw new RifaAlreadyInsertException("Rifa já registrada");
		}

		return rifaRepository.save(rifa);
	}

	public Rifa findById(Long id) {
		return rifaRepository.findById(id).orElseThrow(() -> new RifaNotFoundException("Rifa não encontrada"));
	}

	public void update(Long rifaId, RifaUpdateDTO dto) {
		Rifa rifa = rifaRepository.findById(rifaId).orElseThrow(() -> new RifaNotFoundException("Rifa não encontrada"));

		if (dto.getQdtRifas() != null && dto.getQdtRifas() < rifa.getQdtRifas()) {
			throw new RifaNotFoundException("Não é permitido reduzir a quantidade de rifas.");
		}

		if (dto.getQdtRifas() != null) {
			rifa.setQdtRifas(dto.getQdtRifas());
		}

		if (dto.getDataSorteio() != null) {
			rifa.setDataSorteio(dto.getDataSorteio());
		}

		if (dto.getValorRifa() != null) {
			rifa.setValorRifa(dto.getValorRifa());
		}

		rifaRepository.save(rifa);
	}

	public List<RifaNomesDTO> listarNomesRifas() {
		List<Rifa> rifas = rifaRepository.findAll();
		return rifas.stream()
				.map(RifaNomesDTO::new)
				.collect(Collectors.toList());
	}
}
