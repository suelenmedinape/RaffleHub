package com.controller;

import com.domain.Participante;
import com.dto.*;
import com.service.ParticipanteService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/participantes")
public class ParticipanteController {

    @Autowired
    private ParticipanteService participanteService;

    @PostMapping
    public ResponseEntity<ParticipanteRespostaDTO> insert(@Valid @RequestBody ParticipanteDTO dto) {
        Participante participante = participanteService.insert(dto);
        ParticipanteRespostaDTO resposta = new ParticipanteRespostaDTO("Participante cadastrado com sucesso", participante);
        return ResponseEntity.status(HttpStatus.CREATED).body(resposta);
    }

    @GetMapping("/{rifaId}")
    public ResponseEntity<List<ParticipanteListasDTO>> listarPorRifa(@PathVariable Long rifaId) {
        List<Participante> participantes = participanteService.listarParticipantesPorRifa(rifaId);
        List<ParticipanteListasDTO> dtos = participantes.stream()
                .map(ParticipanteListasDTO::new)
                .toList();

        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{rifaId}/numeros-disponiveis")
    public ResponseEntity<RifaNumerosDTO> getNumerosDisponiveis(@PathVariable Long rifaId) {
        List<Integer> disponiveis = participanteService.numerosDisponiveis(rifaId);
        return ResponseEntity.ok(new RifaNumerosDTO(disponiveis));
    }

    @GetMapping("/{rifaId}/por-nome")
    public ResponseEntity<List<ParticipanteListaDTO>> buscarPorNomeNaRifa(
            @PathVariable Long rifaId,
            @RequestParam String nome
    ) {
        List<ParticipanteListaDTO> participantes = participanteService.buscarPorNomeNaRifa(rifaId, nome);
        return ResponseEntity.ok(participantes);
    }

    @GetMapping("/{rifaId}/por-telefone")
    public ResponseEntity<ParticipanteListaDTO> buscarPorTelefoneNaRifa(
            @PathVariable Long rifaId,
            @RequestParam String telefone
    ) {
        ParticipanteListaDTO dto = participanteService.buscarPorTelefoneNaRifa(rifaId, telefone);
        return ResponseEntity.ok(dto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ParticipanteRespostaDTO> atualizarParticipante(
            @PathVariable Long id,
            @Valid @RequestBody ParticipanteDTO dto
    ) {
        Participante participanteAtualizado = participanteService.atualizar(id, dto);
        ParticipanteRespostaDTO resposta = new ParticipanteRespostaDTO("Participante atualizado com sucesso", participanteAtualizado);
        return ResponseEntity.ok(resposta);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarParticipante(@PathVariable Long id) {
        participanteService.deletar(id);
        return ResponseEntity.noContent().build();
    }

}
