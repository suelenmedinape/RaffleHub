package com.controller;

import com.domain.Client;
import com.domain.Person;
import com.dto.LoginDTO;
import com.dto.LoginResponseDTO;
import com.security.TokenService;
import com.service.ClientService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

	@Autowired
	private ClientService clientService;

	@Autowired
	private TokenService tokenService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@PostMapping("/login")
	public ResponseEntity<LoginResponseDTO> login(@Valid @RequestBody LoginDTO loginDTO) {
		var userNamePassword = new UsernamePasswordAuthenticationToken(loginDTO.getEmail(), loginDTO.getPassword());
		var auth = this.authenticationManager.authenticate(userNamePassword);
		Person person = (Person) auth.getPrincipal();
		var token = tokenService.generateToken((Person)auth.getPrincipal());

		// Adicione a role na resposta
		return ResponseEntity.ok(new LoginResponseDTO(token, person.getRole().name()));
	}
}
