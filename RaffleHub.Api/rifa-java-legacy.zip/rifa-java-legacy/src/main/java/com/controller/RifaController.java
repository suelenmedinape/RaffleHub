package com.controller;

import com.domain.Rifa;
import com.dto.RifaDTO;
import com.dto.RifaNomesDTO;
import com.dto.RifaRespostaDTO;
import com.dto.RifaUpdateDTO;
import com.service.RifaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rifas")
public class RifaController {

    @Autowired
    private RifaService rifaService;

    @PostMapping
    public ResponseEntity<RifaRespostaDTO> insert(@Valid @RequestBody RifaDTO rifaDTO) {
        Rifa rifa = new Rifa();
        rifa.setNomeRifa(rifaDTO.getNomeRifa());
        rifa.setQdtRifas(rifaDTO.getQdtRifas());
        rifa.setValorRifa(rifaDTO.getValorRifa());
        rifa.setDataSorteio(rifaDTO.getDataSorteio());

        Rifa rifaSalva = rifaService.insert(rifa);

        RifaDTO respostaDTO = new RifaDTO();
        respostaDTO.setNomeRifa(rifaSalva.getNomeRifa());
        respostaDTO.setQdtRifas(rifaSalva.getQdtRifas());
        respostaDTO.setValorRifa(rifaSalva.getValorRifa());
        respostaDTO.setDataSorteio(rifaSalva.getDataSorteio());
        respostaDTO.setId(rifaSalva.getId());

        RifaRespostaDTO response = new RifaRespostaDTO("Cadastro Realizado com sucesso", respostaDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PutMapping("/{rifaId}")
    public ResponseEntity<Void> updateRifa(@PathVariable Long rifaId, @RequestBody RifaUpdateDTO dto) {
        rifaService.update(rifaId, dto);

        return ResponseEntity.ok().build();
    }

    @GetMapping("/nomes")
    public ResponseEntity<List<RifaNomesDTO>> listarNomesRifas() {
        List<RifaNomesDTO> nomes = rifaService.listarNomesRifas();
        return ResponseEntity.ok(nomes);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RifaDTO> buscarPorId(@PathVariable Long id) {
        Rifa rifa = rifaService.findById(id);
        return ResponseEntity.ok(new RifaDTO(rifa));
    }
}
