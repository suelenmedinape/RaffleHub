package com.dto;

import com.domain.Participante;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ParticipanteListasDTO {


        private Long id;

        @NotBlank(message = "Nome do participante é obrigatório.")
        private String nomeParticipante;

        @NotBlank(message = "Telefone é obrigatório.")
        private String telefone;

        @NotNull(message = "Lista de números escolhidos não pode ser nula.")
        @Size(min = 1, message = "Pelo menos um número deve ser escolhido.")
        private List<@NotNull(message = "Número não pode ser nulo.") Integer> numerosEscolhidos;

        @NotNull(message = "ID da rifa é obrigatório.")
        private Long rifaId;

        public ParticipanteListasDTO() {
        }

        public ParticipanteListasDTO(Participante participante) {
            this.id = participante.getId();
            this.nomeParticipante = participante.getNomeParticipante();
            this.telefone = participante.getTelefone();
            this.numerosEscolhidos = participante.getNumerosEscolhidos();
            this.rifaId = participante.getRifa().getId();
        }
}
