package com.dto;

import com.domain.Rifa;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
public class RifaDTO {

    private Long id;

    @NotBlank(message = "Nome não pode estar vazio.")
    @Size(min = 4, message = "Nome deve ter pelo menos 4 caracteres.")
    private String nomeRifa;

    @NotNull(message = "Quantidade de rifas é obrigatória.")
    @Min(value = 1, message = "Quantidade de rifas deve ser maior que zero.")
    private Integer qdtRifas;

    @NotNull(message = "Data do sorteio é obrigatória.")
    private LocalDate dataSorteio;

    @NotNull(message = "Valor da rifa é obrigatório.")
    @DecimalMin(value = "0.01", message = "Valor da rifa deve ser maior que zero.")
    private BigDecimal valorRifa;

    public RifaDTO() {
    }

    public RifaDTO(Rifa rifa) {
        this.id = rifa.getId();
        this.nomeRifa = rifa.getNomeRifa();
        this.qdtRifas = rifa.getQdtRifas();
        this.dataSorteio = rifa.getDataSorteio();
        this.valorRifa = rifa.getValorRifa();
    }
}
