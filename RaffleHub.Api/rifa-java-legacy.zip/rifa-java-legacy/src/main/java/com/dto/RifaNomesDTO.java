package com.dto;

import com.domain.Rifa;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RifaNomesDTO {

    private Long id;

    @NotBlank(message = "Nome não pode estar vazio.")
    @Size(min = 4, message = "Nome deve ter pelo menos 4 caracteres.")
    private String nomeRifa;

    public RifaNomesDTO() {
    }

    public RifaNomesDTO(Rifa rifa) {
        this.id = rifa.getId();
        this.nomeRifa = rifa.getNomeRifa();
    }
}
