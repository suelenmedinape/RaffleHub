package com.dto;

import com.domain.Rifa;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class RifaNumerosDTO {
    private List<Integer> numerosDisponiveis;

    public RifaNumerosDTO(List<Integer> numerosDisponiveis) {
        this.numerosDisponiveis = numerosDisponiveis;
    }
}

