package com.dto;

import com.domain.Participante;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ParticipanteRespostaDTO {

    private String mensagem;
    private Long id;
    private String nomeParticipante;
    private String telefone;
    private List<Integer> numerosEscolhidos;
    private Long rifaId;

    public ParticipanteRespostaDTO() {
    }

    public ParticipanteRespostaDTO(String mensagem, Participante participante) {
        this.mensagem = mensagem;
        this.id = participante.getId();
        this.nomeParticipante = participante.getNomeParticipante();
        this.telefone = participante.getTelefone();
        this.numerosEscolhidos = participante.getNumerosEscolhidos();
        this.rifaId = participante.getRifa().getId();
    }
}

