package com.exceptions;

import java.util.List;
import java.util.Map;

public class ParticipanteValidacaoException extends RuntimeException {
    private final Map<String, List<String>> errors;

    public ParticipanteValidacaoException(Map<String, List<String>> errors) {
        this.errors = errors;
    }

    public Map<String, List<String>> getErrors() {
        return errors;
    }
}
