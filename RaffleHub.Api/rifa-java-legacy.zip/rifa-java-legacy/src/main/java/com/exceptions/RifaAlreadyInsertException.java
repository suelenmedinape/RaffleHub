package com.exceptions;

public class RifaAlreadyInsertException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public RifaAlreadyInsertException(String mensagem) {
        super(mensagem);
    }
}
