package com.exceptions;

public class RifaNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public RifaNotFoundException(String mensagem) {
        super(mensagem);
    }
}
