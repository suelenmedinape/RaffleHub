package com.exceptions;

public class ParticipanteException extends RuntimeException {

    public ParticipanteException(String mensagem) {
        super(mensagem);
    }
}
