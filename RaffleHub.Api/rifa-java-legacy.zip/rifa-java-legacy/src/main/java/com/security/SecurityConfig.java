package com.security;

import com.enums.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
	
	@Autowired
	private SecurityFilter securityFilter;

	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
	    return httpSecurity
	            .csrf(csrf -> csrf.disable())
	            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
	            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
	            .authorizeHttpRequests(authorize -> authorize
						.requestMatchers("/h2-console/**").permitAll()
						.requestMatchers("/auth/**").permitAll()

						.requestMatchers(HttpMethod.GET, "/rifas/nomes").permitAll()
						.requestMatchers(HttpMethod.GET, "/rifas/{id}").permitAll()

						.requestMatchers(HttpMethod.POST, "/rifas").hasRole(Role.ROLE_ADMIN.getRoleName())

						.requestMatchers(HttpMethod.PUT, "/rifas/{rifaId}").hasRole(Role.ROLE_ADMIN.getRoleName())

						.requestMatchers(HttpMethod.GET, "/participantes/{id}").permitAll()
						.requestMatchers(HttpMethod.GET, "/participantes/{rifaId}/numeros-disponiveis").permitAll()
						.requestMatchers(HttpMethod.GET, "/participantes/{rifaId}/por-nome").permitAll()
						.requestMatchers(HttpMethod.GET, "/participantes/{rifaId}/por-telefone").permitAll()
						.requestMatchers(HttpMethod.GET, "/participantes/{rifaId}").permitAll()

						.requestMatchers(HttpMethod.POST, "/participantes")
						.hasAnyRole(Role.ROLE_ADMIN.getRoleName(), Role.ROLE_CLIENT.getRoleName())

						.requestMatchers(HttpMethod.PUT, "/participantes/{id}")
						.hasRole(Role.ROLE_ADMIN.getRoleName())

						.requestMatchers(HttpMethod.DELETE, "/participantes/{id}")
						.hasRole(Role.ROLE_ADMIN.getRoleName())


						.anyRequest().authenticated())
	            .addFilterBefore(securityFilter, UsernamePasswordAuthenticationFilter.class)
	            .headers(headers -> headers.frameOptions().sameOrigin())
	            .build();
	}

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.addAllowedOrigin("https://rifas-iff-road.vercel.app");
        configuration.addAllowedMethod("*");
        configuration.addAllowedHeader("*");
        configuration.setAllowCredentials(true);
        configuration.setMaxAge(3600L);
        
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
    
    @Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
    	return authenticationConfiguration.getAuthenticationManager();
    }
    
    @Bean
    PasswordEncoder passwordEncoder() {
    	return new BCryptPasswordEncoder();
    }
}
