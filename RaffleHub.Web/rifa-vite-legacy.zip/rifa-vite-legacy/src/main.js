import { RifaController } from "./controller/RifaController.js"
import { ParticipanteController } from "./controller/ParticipanteController.js"
import { RifasService } from "./service/RifasService.js"
import { ParticipantesService } from "./service/ParticipantesService.js"
import { AuthService } from "./service/AuthService.js"
import { Input } from "./ui/input.js"
import { Alert } from "./ui/alert.js"
import { Loading } from "./ui/loading.js"
import { Checkbox } from "./ui/checkbox.js"
import { Participantes } from "./ui/participantes.js"
import { DropdownLista } from "./ui/dropdown.js"
import {Login} from "./controller/login.js";

class App {
    constructor() {
        this.authService = new AuthService()
        this.loginBtn = document.querySelector("#loginBtn")
        this.logoutBtn = document.querySelector("#logoutBtn")
        this.loading = new Loading()
    }

    async init() {
        try {
            this.setupAuthUI()

            const rifaService = new RifasService()
            const participanteService = new ParticipantesService()
            const authService = new AuthService()
            const input = new Input()
            const alert = new Alert()
            const checkbox = new Checkbox()
            const dropdown = new DropdownLista()
            const participanteLista = new Participantes(checkbox)

            const rifaController = new RifaController({
                rifaService,
                input,
                alert,
                loading: this.loading,
                checkbox,
                participanteService,
                dropdown,
            })

            const participanteController = new ParticipanteController({
                participanteService,
                input,
                alert,
                loading: this.loading,
                checkbox,
                participanteLista,
                dropdown,
            })

            const loginController = new Login()

            rifaController.init()
            participanteController.init()
            loginController.login()

            await rifaController.carregarRifa()

        } catch (error) {
            console.error("Erro ao inicializar aplicação:", error)
            const alert = new Alert()
            alert.show("Erro ao carregar o sistema. Recarregue a página.", "error")
        } finally {
            this.loading.hideGlobalLoading()
        }
    }

    setupAuthUI() {
        const role = localStorage.getItem("role")
        const token = localStorage.getItem("token")

        if (token && role) {
            this.showClientUI()
            this.setupLogout()
        } else {
            this.showGuestUI()
        }
    }

    hideAll() {
        if (this.loginBtn) this.loginBtn.style.display = "none"
        if (this.logoutBtn) this.logoutBtn.style.display = "none"
    }

    showClientUI() {
        this.hideAll()
        if (this.logoutBtn) this.logoutBtn.style.display = "block"
    }

    showGuestUI() {
        this.hideAll()
        if (this.loginBtn) this.loginBtn.style.display = "block"
    }

    setupLogout() {
        this.logoutBtn?.addEventListener("click", (e) => {
            e.preventDefault()
            this.authService.logout()
            window.location.reload()
        })
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const app = new App()
    app.init()
})