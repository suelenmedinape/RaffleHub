import { RifasService } from "../service/RifasService.js"

export class DropdownController {

    constructor() {
        this.rifaService = new RifasService()
    }

    eventoClick(li) {
        li.addEventListener("click", async () => {
            const nomeRifa = li.dataset.nome
            const id = li.dataset.id

            console.log("Nome:", nomeRifa)
            console.log("ID:", id)

            const $dadosRifa = {
                id: id,
                nome: nomeRifa
            }

            const { response, responseData } = await this.rifaService.buscarPorId(id)
            console.log(response)
            console.log(responseData)
            localStorage.setItem('rifaCarregada', JSON.stringify($dadosRifa))
            location.reload()
        })
    }
}