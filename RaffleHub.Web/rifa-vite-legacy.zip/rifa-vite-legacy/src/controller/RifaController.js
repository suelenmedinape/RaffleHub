import { Checkbox } from "../ui/checkbox.js"
import { ParticipantesService } from "../service/ParticipantesService.js"
import { DropdownLista } from "../ui/dropdown.js"
import { formatDateToBR, formatDateToISO } from "../utils/helpers.js"
import { FormUtils } from "../utils/form-utils.js"

export class RifaController {
    constructor({ rifaService, input, alert, loading, checkbox, participanteService, dropdown }) {
        this.rifaService = rifaService
        this.input = input
        this.alert = alert
        this.loading = loading
        this.checkbox = checkbox || new Checkbox()
        this.participanteService = participanteService || new ParticipantesService()
        this.dropdown = dropdown || new DropdownLista()
        this._formNovaRifa = document.querySelector("#form-nova-rifa")
        this._formEditarRifa = document.querySelector("#form-editar-rifa")
        this._alertNovaRifa = document.querySelector("#alert-nova-rifa")
        this._alertEditarRifa = document.querySelector("#alert-editar-rifa")
        this._alertRifa = document.querySelector("#alert-principal")
        this._nomeRifaCarregada = document.querySelector("#nome-rifa-carregada")
        this._dataSorteioMostrar = document.querySelector("#data-sorteio")
        this._qauntidadeNumerosMostrar = document.querySelector("#quantidade-de-rifas")
        this._precoRifa = document.querySelector("#valor-rifa")
    }

    init() {
        this.novaRifa()
        this.editarRifa()
        this.listarNomesRifas()
    }

    novaRifa() {
        this._formNovaRifa.addEventListener("submit", async (e) => {
            e.preventDefault()
            const _nomeRifa = this._formNovaRifa.querySelector("#nome-nova-rifa").value.trim()
            const _preco = Number.parseFloat(this._formNovaRifa.querySelector("#preco-nova-rifa").value.replace(",", "."))
            const _qdtRifas = Number.parseInt(this._formNovaRifa.querySelector("#qdt-numeros-nova-rifa").value)
            const _dataSorteio = this._formNovaRifa.querySelector("#dt-sorteio-nova-rifa").value
            //const _dataSorteio = formatDateToISO(dataSorteioBr)

            this.loading.showButtonLoading("#btn-criar-rifa")

            try {
                const $formRifa = {
                    nomeRifa: _nomeRifa,
                    qdtRifas: _qdtRifas,
                    dataSorteio: _dataSorteio,
                    valorRifa: _preco,
                }

                const { response, responseData } = await this.rifaService.novaRifa($formRifa)

                if (response.ok) {
                    this.alert.gerarAlerta({ mensagem: "Rifa criada com sucesso", type: "success" }, this._alertNovaRifa)
                    this.rifaService.salvarRifa(responseData.rifa.id, responseData.rifa.nomeRifa, responseData.rifa.qdtRifas)

                    // Limpar formulário
                    FormUtils.limparFormulario("#form-nova-rifa")

                    setTimeout(() => location.reload(), 2000)
                }
            } catch (e) {
                if (e.type === "validation") {
                    e.errors.forEach((err) => {
                        this.input.inputError({ type: "error", field: err.field, mensagem: err.message })
                    })
                } else {
                    this.alert.gerarAlerta({ mensagem: `Erro ao criar rifa: ${e.message}`, type: "error" }, this._alertNovaRifa)
                    console.error("Erro desconhecido", e)
                }
            } finally {
                this.loading.hideButtonLoading("#btn-criar-rifa")
            }
        })
    }

    async editarRifa() {
        const { id } = JSON.parse(localStorage.getItem("rifaCarregada")) || {}
        let rifaCompleta

        try {
            const { response, responseData } = await this.rifaService.buscarPorId(id)
            rifaCompleta = responseData
        } catch (e) {
            console.error("Erro ao buscar rifa para edição:", e)
            return
        }

        if (!rifaCompleta) return

        const { nomeRifa, qdtRifas, dataSorteio, valorRifa } = rifaCompleta
        const nomeInput = this._formEditarRifa.querySelector("#nome-rifa-edit")
        const precoInput = this._formEditarRifa.querySelector("#preco-edit")
        const qdtRifasInput = this._formEditarRifa.querySelector("#qdt-numeros-edit")
        const dataSorteioInput = this._formEditarRifa.querySelector("#dt-sorteio-edit")

        if (nomeInput) nomeInput.value = nomeRifa
        if (precoInput) precoInput.value = valorRifa?.toString().replace(".", ",") || ""
        if (qdtRifasInput) qdtRifasInput.value = qdtRifas || ""
        if (dataSorteioInput && dataSorteio) {
            try {
                const [ano, mes, dia] = dataSorteio.split("-")
                const dateObj = new Date(`${ano}-${mes}-${dia}`)
                const picker = dataSorteioInput.datepicker
                if (picker) {
                    picker.setDate(dateObj)
                } else {
                    const dataFormatada = `${dia}/${mes}/${ano}`
                    dataSorteioInput.value = dataFormatada
                    setTimeout(() => {
                        const dp = dataSorteioInput.datepicker
                        if (dp) {
                            dp.setDate(dateObj)
                        } else {
                            dataSorteioInput.value = dataFormatada
                        }
                    }, 300)
                }
            } catch (error) {
                console.error("Erro ao definir data:", error)
                dataSorteioInput.value = dataSorteio
            }
        }

        this._formEditarRifa.addEventListener("submit", async (e) => {
            e.preventDefault()
            const _preco = Number.parseFloat(precoInput.value.replace(",", "."))
            const _qdtRifas = Number.parseInt(qdtRifasInput.value)
            const _dataSorteioBr = dataSorteioInput.value
            const _dataSorteio = formatDateToISO(_dataSorteioBr)

            this.loading.showButtonLoading("#btn-editar-rifa")

            try {
                const $formRifa = {
                    nomeRifa: nomeInput.value.trim(),
                    qdtRifas: _qdtRifas,
                    dataSorteio: _dataSorteio,
                    valorRifa: _preco,
                }

                const { response } = await this.rifaService.editarRifa(id, $formRifa)

                if (response.ok) {
                    this.alert.gerarAlerta({ mensagem: "Rifa editada com sucesso", type: "success" }, this._alertEditarRifa)

                    // Limpar formulário
                    FormUtils.limparFormulario("#form-editar-rifa")

                    setTimeout(() => location.reload(), 2000)
                }
            } catch (e) {
                if (e.type === "validation") {
                    e.errors.forEach((err) => {
                        this.input.inputError({ type: "error", field: err.field, mensagem: err.message })
                    })
                } else {
                    this.alert.gerarAlerta({ mensagem: `${e}`, type: "error" }, this._alertEditarRifa)
                    console.error("Erro desconhecido", e)
                }
            } finally {
                this.loading.hideButtonLoading("#btn-editar-rifa")
            }
        })
    }

    listarNomesRifas() {
        this.dropdown.listaRifasDisponiveis()
    }

    async carregarRifa() {
        const rifa = JSON.parse(localStorage.getItem("rifaCarregada"))
        if (!rifa) {
            this._nomeRifaCarregada.innerHTML = "Nenhuma rifa selecionada"
            return
        }

        try {
            const { responseData } = await this.rifaService.buscarPorId(rifa.id)
            const { responseData: numerosData } = await this.participanteService.carregarCheckboxComDisponibilidade(rifa.id)

            this.checkbox.criarCheckbox(responseData.qdtRifas, numerosData.numerosDisponiveis)
            console.log(responseData)
            this._nomeRifaCarregada.innerHTML = responseData.nomeRifa
            this._dataSorteioMostrar.innerHTML = formatDateToBR(responseData.dataSorteio)
            this._qauntidadeNumerosMostrar.innerHTML = responseData.qdtRifas
            this._precoRifa.innerHTML = responseData.valorRifa.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
        } catch (error) {
            this.alert.gerarAlerta({ mensagem: error.message || "Erro ao carregar rifa", type: "error" }, this._alertRifa)
            console.error(error)
        }
    }
}