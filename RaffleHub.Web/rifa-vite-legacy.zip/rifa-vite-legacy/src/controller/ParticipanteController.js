import {RifasService} from "../service/RifasService.js"
import {FormUtils} from "../utils/form-utils.js"
import { jsPDF } from "jspdf";
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://gtmicyurecpngevsgpuq.supabase.co" // coloque sua URL Supabase aqui
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd0bWljeXVyZWNwbmdldnNncHVxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM5MDAxMjAsImV4cCI6MjA2OTQ3NjEyMH0.KSoMfFEKxgvrkXBWQzD9ElxFgE4pBErTUFvqXkppJPc" // coloque sua anon public key aqui
const supabase = createClient(supabaseUrl, supabaseKey)

export class ParticipanteController {
    constructor({participanteService, input, alert, loading, checkbox, participanteLista, dropdown}) {
        this.participanteService = participanteService
        this.input = input
        this.alert = alert
        this.loading = loading
        this.checkbox = checkbox
        this.dropdown = dropdown
        this.participanteLista = participanteLista
        this.rifaService = new RifasService()
        this._formNovoParticipante = document.querySelector("#form-participante")
        this._alertTelaPrincipal = document.querySelector("#alert-principal")
        this._formBuscarParticipante = document.querySelector("#form-buscar-participante")
    }

    init() {
        this.novoParticipante()
        this.buscarParticipante()
        // Carregar participantes ao inicializar
        this.listarParticipantes()
    }

    novoParticipante() {
        const {id} = JSON.parse(localStorage.getItem("rifaCarregada")) || 0
        this._formNovoParticipante.addEventListener("submit", async (e) => {
            e.preventDefault()
            const _nome = this._formNovoParticipante.querySelector("#nome").value.trim()
            const _telefone = this._formNovoParticipante.querySelector("#telefonep").value.trim()
            const telefoneLimpo = _telefone.replace(/\D/g, "")
            const numerosEscolhidos = Array.from(document.querySelectorAll('.ul-numeros input[type="checkbox"]:checked')).map(
                (checkbox) => Number.parseInt(checkbox.value),
            )

            this.loading.showButtonLoading("#btn-salvar-participante")

            try {
                const formParticipante = {
                    nomeParticipante: _nome,
                    telefone: telefoneLimpo,
                    numerosEscolhidos: numerosEscolhidos,
                    rifaId: Number(id),
                }
                const {response} = await this.participanteService.novoParticipante(formParticipante)

                if (response.ok) {
                    this.alert.gerarAlerta(
                        {mensagem: "Participante adicionado com sucesso", type: "success"},
                        this._alertTelaPrincipal,
                    )

                    await this.gerarComprovanteECompartilhar(formParticipante, numerosEscolhidos)

                    FormUtils.limparFormulario("#form-participante")

                    if (this.checkbox && this.checkbox.limparSelecao) {
                        this.checkbox.limparSelecao()
                    }

                    if (this.checkbox && this.checkbox.atualizarCheckboxes) {
                        await this.checkbox.atualizarCheckboxes()
                    }

                    await this.listarParticipantes()

                    setTimeout(() => {
                        const container = document.querySelector("#participants-list-container")
                        if (container && container.firstElementChild) {
                            container.firstElementChild.scrollIntoView({behavior: "smooth", block: "center"})
                        }
                    }, 100)

                }
            } catch (e) {
                if (e.type === "validation") {
                    e.errors.forEach((err) => {
                        this.input.inputError({type: "error", field: err.field, mensagem: err.message})
                    })
                } else {
                    this.alert.gerarAlerta(
                        {mensagem: `Erro ao adicionar participante: ${e.message}`, type: "error"},
                        this._alertTelaPrincipal,
                    )
                    console.error("Erro desconhecido", e)
                }
            } finally {
                this.loading.hideButtonLoading("#btn-salvar-participante")
            }
        })
    }

    async listarParticipantes() {
        const {id} = JSON.parse(localStorage.getItem("rifaCarregada")) || {}
        if (!id) {
            console.warn("Nenhuma rifa carregada")
            return
        }

        try {
            const {response: respRifa, responseData: dadosRifa} = await this.rifaService.buscarPorId(id)
            const qdt = dadosRifa.qdtRifas
            const {response, responseData} = await this.participanteService.listarParticipantes(id)

            console.log("Dados dos participantes:", responseData) // Debug

            if (response.ok && respRifa.ok) {
                const participantes = Array.isArray(responseData) ? responseData : responseData ? [responseData] : []
                this.participanteLista.carregarParticipantes(participantes, qdt)
            }
        } catch (e) {
            console.error("Erro ao listar participantes:", e)
        }
    }

    buscarParticipante() {
        const {id} = JSON.parse(localStorage.getItem("rifaCarregada")) || {}
        this._formBuscarParticipante.addEventListener("submit", async (e) => {
            e.preventDefault()
            const _valor = this._formBuscarParticipante.querySelector("#simple-search").value.trim()

            if (!_valor) {
                await this.listarParticipantes()
                return
            }

            this.loading.showButtonLoading("#btn-buscar-participante")

            try {
                const isTelefone = /^\d{8,15}$/.test(_valor.replace(/\D/g, ""))
                let participantes = []

                if (isTelefone) {
                    const {response, responseData} = await this.participanteService.buscarPorTelefone(id, _valor)
                    if (response.ok) {
                        participantes = responseData ? [responseData] : []
                    }
                } else {
                    const {response, responseData} = await this.participanteService.buscarPorNome(id, _valor)
                    if (response.ok) {
                        participantes = Array.isArray(responseData) ? responseData : responseData ? [responseData] : []
                    }
                }

                const {response: respRifa, responseData: dadosRifa} = await this.rifaService.buscarPorId(id)
                const qdt = dadosRifa.qdtRifas
                this.participanteLista.carregarParticipantes(participantes, qdt)
            } catch (e) {
                console.error("Erro na busca:", e)
                if (e.type === "validation") {
                    e.errors.forEach((err) => {
                        this.input.inputError({type: "error", field: err.field, mensagem: err.message})
                    })
                } else {
                    console.error("Erro desconhecido", e)
                }
            } finally {
                this.loading.hideButtonLoading("#btn-buscar-participante")
            }
        })
    }

    async gerarComprovanteECompartilhar(participante, numeros) {
        const doc = new jsPDF({orientation: 'portrait', unit: 'mm', format: 'a4'})

        const imageUrl = '/docFundo.jpg' // imagem do fundo (coloque na pasta /public/imagens/)
        const imageResponse = await fetch(imageUrl)
        const imageBlob = await imageResponse.blob()

        const imageBase64 = await new Promise((resolve) => {
            const reader = new FileReader()
            reader.onloadend = () => resolve(reader.result)
            reader.readAsDataURL(imageBlob)
        })

        doc.addImage(imageBase64, 'JPEG', 0, 0, 210, 297) // A4 em mm

        doc.setFont("helvetica", "normal")
        doc.setFontSize(12)
        doc.setTextColor(0, 0, 0)

        doc.text(`Nome: ${participante.nomeParticipante}`, 20, 80)
        doc.text(`Telefone: ${participante.telefone}`, 20, 90)
        doc.text(`Números escolhidos: ${numeros.join(", ")}`, 20, 100)

        const pdfBlob = doc.output("blob")
        const timestamp = new Date().toISOString().replace(/[-:.]/g, '')
        const fileName = `comprovantes/comprovante_${participante.nomeParticipante.replace(/\s+/g, "_")}_${timestamp}.pdf`

        const {data, error} = await supabase.storage
            .from("pdfs")
            .upload(fileName, pdfBlob, {
                cacheControl: "3600",
                upsert: true,
                contentType: "application/pdf",
            })

        if (error) {
            console.error("Erro ao enviar PDF:", error)
            alert("Erro ao enviar comprovante.")
            return
        }

        const publicUrl = supabase.storage.from("pdfs").getPublicUrl(fileName).data.publicUrl

        const telefoneNumerico = participante.telefone.replace(/\D/g, '')
        const numeroComDDI = telefoneNumerico.startsWith('55') ? telefoneNumerico : `55${telefoneNumerico}`
        const mensagem = `Olá! Aqui está seu comprovante da rifa: ${publicUrl}`;
        await navigator.clipboard.writeText(mensagem);

        const linkWhatsApp = `https://api.whatsapp.com/send?phone=${numeroComDDI}&text=${encodeURIComponent(mensagem)}`;
        window.open(linkWhatsApp, "_blank");

    }
}