import axios from "axios"

export class ParticipantesService {
    #baseUrl = `https://yelping-lyssa-iff-road-715cb09c.koyeb.app/participantes`
    #role = localStorage.getItem("role");
    #token = localStorage.getItem("token");

    async novoParticipante(formParticipante) {
        if (this.#role === "ROLE_ADMIN" || this.#role === "ROLE_CLIENT") {
            try {
                const response = await axios.post(`${this.#baseUrl}`, formParticipante, {
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${this.#token}`
                    },
                })
                return {response: {ok: true}, responseData: response.data}
            } catch (e) {
                const data = e.response?.data;

                if (Array.isArray(data)) {
                    throw {type: 'validation', errors: data};
                } else {
                    const mensagemErro = 'Erro ao criar rifa. ' + (data?.message || e.message);
                    throw new Error(mensagemErro);
                }
            }
        } else {
            throw new Error("Ação não permitida. Você não tem permissão para criar participantes. Relaize login");
        }
    }

    async editarParticipante(idParticipante, formParticipante) {
        if (this.#role === "ROLE_ADMIN") {
            try {
                const response = await axios.put(`${this.#baseUrl}/${idParticipante}`, formParticipante,
                    {headers: {"Content-Type": "application/json", "Authorization": `Bearer ${this.#token}`},}
                )
                return {
                    response: {ok: response.status >= 200 && response.status < 300},
                    responseData: response.data
                }
            } catch (e) {
                const data = e.response?.data;

                if (Array.isArray(data)) {
                    throw {type: 'validation', errors: data};
                } else {
                    const mensagemErro = data?.message || e.message || "Erro desconhecido"
                    throw new Error(mensagemErro)
                }
            }
        } else {
            throw new Error("Ação não permitida. Você não tem permissão para editar participantes. Peça a um administrador.");
        }
    }

    async removerParticipante(idParticipante) {
        if (this.#role === "ROLE_ADMIN") {
            try {
                const response = await axios.delete(`${this.#baseUrl}/${idParticipante}`, {
                    headers: {"Content-Type": "application/json", "Authorization": `Bearer ${this.#token}`},
                })
                return {response: {ok: response.status >= 200 && response.status < 300}, responseData: response.data}
            } catch (e) {
                throw new Error(`Erro ao remover participante: ${e.response?.data?.message || e.message}`)
            }
        } else {
            throw new Error("Ação não permitida. Você não tem permissão para remover participantes. Peça a um administrador.");
        }
    }

    async carregarCheckboxComDisponibilidade(idRifa) {
        try {
            const response = await axios.get(`${this.#baseUrl}/${idRifa}/numeros-disponiveis`, {
                headers: {"Content-Type": "application/json", "Authorization": `Bearer ${this.#token}`},
            })
            return {response: {ok: true}, responseData: response.data}
        } catch (e) {
            throw new Error(`Erro ao carregar números disponíveis: ${e.response?.data?.message || e.message}`)
        }
    }

    async listarParticipantes(idRifa) {
        try {
            const response = await axios.get(`${this.#baseUrl}/${idRifa}`, {
                headers: {"Content-Type": "application/json", "Authorization": `Bearer ${this.#token}`},
            })
            return {response: {ok: true}, responseData: response.data};

        } catch (e) {
            throw new Error(`Erro ao carregar números disponíveis: ${e.response?.data?.message || e.message}`)
        }
    }

    async buscarPorNome(idRifa, nome) {
        console.log(`${this.#baseUrl}/${idRifa}/por-nome?nome=${nome}`)
        try {
            const response = await axios.get(`${this.#baseUrl}/${idRifa}/por-nome?nome=${nome}`, {
                headers: {"Content-Type": "application/json", "Authorization": `Bearer ${this.#token}`},
            })
            return {response: {ok: true}, responseData: response.data}

        } catch (e) {
            throw new Error(`Erro ao buscar por nome: ${e.response?.data?.message || e.message}`)
        }
    }

    async buscarPorTelefone(idRifa, telefone) {
        console.log(`${this.#baseUrl}/${idRifa}/por-telefone?telefone=${telefone}`)
        try {
            const response = await axios.get(`${this.#baseUrl}/${idRifa}/por-telefone?telefone=${telefone}`, {
                headers: {"Content-Type": "application/json", "Authorization": `Bearer ${this.#token}`},
            })
            return {response: {ok: true}, responseData: response.data}
        } catch (e) {
            throw new Error(`Erro ao buscar por telefone: ${e.response?.data?.message || e.message}`)
        }
    }
}
