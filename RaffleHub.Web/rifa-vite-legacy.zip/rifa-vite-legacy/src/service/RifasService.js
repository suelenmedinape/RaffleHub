import axios from "axios"

export class RifasService {
    #baseUrl = "https://yelping-lyssa-iff-road-715cb09c.koyeb.app/rifas"
    #role = localStorage.getItem("role");
    #token = localStorage.getItem("token");

    async novaRifa(formRifa) {
        if (this.#role === "ROLE_ADMIN") {
            try {
                const response = await axios.post(this.#baseUrl, formRifa, {
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${this.#token}`
                    },
                })
                return {response: {ok: true}, responseData: response.data}
            } catch (e) {
                throw new Error(`Erro ao criar rifa: ${e.response?.data?.message || e.message}`)
            }
        } else {
            throw new Error("Ação não permitida. Você não tem permissão para criar rifas.")
        }
    }

    async editarRifa(id, formRifa) {
        if (this.#role === "ROLE_ADMIN") {
            try {
                const response = await axios.put(`${this.#baseUrl}/${id}`, formRifa, {
                    headers: {"Content-Type": "application/json", "Authorization": `Bearer ${this.#token}`},
                })
                return {response: {ok: true}, responseData: response.data}
            } catch (e) {
                throw new Error(`${e.response?.data?.message || e.message}`)
            }
        } else {
            throw new Error("Ação não permitida. Você não tem permissão para editar rifas.")
        }
    }

    salvarRifa(rifaId, rifaNome, qdtRifas) {
        const $dadosRifa = {
            id: rifaId,
            nome: rifaNome,
            qdt: qdtRifas
        }
        try {
            localStorage.setItem("rifaCarregada", JSON.stringify($dadosRifa))
        } catch (e) {
            throw new Error(`Erro ao salvar rifa: ${e.message}`)
        }
    }

    async buscarPorId(id) {
        try {
            const response = await axios.get(`${this.#baseUrl}/${id}`)

            return { response: { ok: true }, responseData: response.data }
        } catch (e) {
            throw new Error(`Erro ao buscar rifa: ${e.response?.data?.message || e.message}`)
        }
    }

    async listarRifas() {
        try {
            const response = await axios.get(`${this.#baseUrl}/nomes`)
            return { response: { ok: true }, responseData: response.data }
        } catch (e) {
            throw new Error(`Erro ao listar rifas: ${e.response?.data?.message || e.message}`)
        }
    }
}