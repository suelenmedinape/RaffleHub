import { ParticipantesService } from "../service/ParticipantesService.js"
import {RifasService} from "../service/RifasService.js";

export class Checkbox {
    constructor() {
        this.participanteService = new ParticipantesService()
        this.rifaService = new RifasService()
        this.numerosEscolhidos = []
        this.ulNumeros = document.querySelector(".ul-numeros")
        this.infoNumerosContainer = document.querySelector("#numeros-selecionados-info")
        this.listaNumerosContainer = document.querySelector("#lista-numeros-selecionados")
    }

    criarCheckbox(quantidade, numerosDisponiveis) {
        if (!this.ulNumeros) {
            console.error("Container de números não encontrado")
            return
        }

        this.ulNumeros.innerHTML = ""
        this.numerosEscolhidos = []
        this.atualizarInfoNumeros()

        for (let i = 1; i <= quantidade; i++) {
            const isDisponivel = numerosDisponiveis.includes(i)
            const li = document.createElement("li")

            li.innerHTML = `
                <input type="checkbox" id="option-${i}" value="${i}" 
                       class="hidden peer" ${!isDisponivel ? "disabled" : ""}>
                <label for="option-${i}" 
                       class="flex items-center justify-center w-10 h-10 text-sm font-semibold rounded-lg cursor-pointer 
                              ${
                !isDisponivel
                    ? "bg-red-100 border-red-300 text-red-600 cursor-not-allowed"
                    : "text-gray-500 bg-white border-2 border-gray-200 peer-checked:border-green-600 peer-checked:text-green-600 hover:text-gray-600 hover:bg-gray-50"
            }">
                    ${i}
                </label>
            `

            this.ulNumeros.appendChild(li)

            if (isDisponivel) {
                const checkbox = li.querySelector(`#option-${i}`)
                checkbox.addEventListener("change", (e) => {
                    this.handleCheckboxChange(e)
                })
            }
        }
    }

    handleCheckboxChange(e) {
        const numero = Number.parseInt(e.target.value)

        if (e.target.checked) {
            if (!this.numerosEscolhidos.includes(numero)) {
                this.numerosEscolhidos.push(numero)
            }
        } else {
            this.numerosEscolhidos = this.numerosEscolhidos.filter((n) => n !== numero)
        }

        this.numerosEscolhidos.sort((a, b) => a - b)
        this.atualizarInfoNumeros()
    }

    atualizarInfoNumeros() {
        if (!this.infoNumerosContainer || !this.listaNumerosContainer) return

        if (this.numerosEscolhidos.length > 0) {
            this.infoNumerosContainer.classList.remove("hidden")
            this.listaNumerosContainer.innerHTML = this.numerosEscolhidos
                .map((num) => `<span class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs">${num}</span>`)
                .join("")
        } else {
            this.infoNumerosContainer.classList.add("hidden")
            this.listaNumerosContainer.innerHTML = ""
        }
    }

    limparSelecao() {
        const checkboxes = this.ulNumeros.querySelectorAll('input[type="checkbox"]:checked')
        checkboxes.forEach((checkbox) => {
            checkbox.checked = false
        })

        this.numerosEscolhidos = []

        this.atualizarInfoNumeros()
    }

    async atualizarCheckboxes() {
        const rifaCarregada = JSON.parse(localStorage.getItem("rifaCarregada"))
        if (!rifaCarregada || !rifaCarregada.id) {
            console.warn("Nenhuma rifa carregada para atualizar checkboxes")
            return
        }

        try {
            // Busca os dados completos da rifa para ter acesso à quantidade
            const { response: respRifa, responseData: dadosRifa } = await this.rifaService.buscarPorId(
                rifaCarregada.id
            )

            if (!respRifa.ok) {
                console.warn("Erro ao buscar dados da rifa para checkboxes")
                return
            }

            const { response, responseData } = await this.participanteService.carregarCheckboxComDisponibilidade(
                rifaCarregada.id
            )

            if (response.ok) {
                const quantidade = dadosRifa.qdtRifas
                const numerosDisponiveis = responseData.numerosDisponiveis
                this.criarCheckbox(quantidade, numerosDisponiveis)
                console.log("Checkboxes atualizados com sucesso")
            }
        } catch (error) {
            console.error("Erro ao atualizar checkboxes:", error)
        }
    }

}
