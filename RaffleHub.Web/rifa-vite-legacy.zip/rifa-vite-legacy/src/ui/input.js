export class Input {
    inputError({ type, field, mensagem }) {
        const divInput = document.querySelector(`#${field}`);
        if (!divInput) return;

        const label = divInput.querySelector("label");
        const input = divInput.querySelector("input, textarea, select");
        const errorDiv = divInput.querySelector("div[role='alert']");

        if (type === "error") {
            label.classList.add("text-red-700", "dark:text-red-500");
            input.classList.add(
                "bg-red-50",
                "border-red-500",
                "text-red-900",
                "placeholder-red-700",
                "dark:text-red-500",
                "dark:placeholder-red-500",
                "dark:border-red-500"
            );
            input.placeholder = "Corrija o erro";

            errorDiv.textContent = mensagem;
            errorDiv.classList.remove("hidden");
        }

        setTimeout(() => {
            label.classList.remove("text-red-700", "dark:text-red-500");
            input.classList.remove(
                "bg-red-50",
                "border-red-500",
                "text-red-900",
                "placeholder-red-700",
                "dark:text-red-500",
                "dark:placeholder-red-500",
                "dark:border-red-500"
            );
            input.placeholder = input.getAttribute("data-original-placeholder") || "";
            errorDiv.textContent = "";
            errorDiv.classList.add("hidden");
        }, 3000);
    }
}