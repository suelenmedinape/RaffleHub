import { sanitizeHTML } from "../utils/helpers.js"

export class Alert {
    constructor(timeoutManager) {
        this.timeoutManager = timeoutManager
        this.activeAlerts = new Set()
    }

    gerarAlerta(dados, alertElement) {
        if (!alertElement) return

        this.limparAlerta(alertElement)

        alertElement.classList.remove("hidden")
        alertElement.setAttribute("role", "alert")
        alertElement.setAttribute("aria-live", "assertive")

        const mensagemSanitizada = sanitizeHTML(dados.mensagem)

        if (dados.type === "error") {
            alertElement.className =
                "alert flex items-center p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400 border border-red-200 dark:border-red-800"
            alertElement.innerHTML = `
                <svg class="shrink-0 inline w-4 h-4 me-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
                </svg>
                <div class="flex-1">
                    <span class="font-medium">Erro!</span> ${mensagemSanitizada}
                </div>
                <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-red-50 text-red-500 rounded-lg focus:ring-2 focus:ring-red-400 p-1.5 hover:bg-red-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-red-400 dark:hover:bg-gray-700" aria-label="Fechar alerta">
                    <span class="sr-only">Fechar</span>
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                    </svg>
                </button>
            `
        } else if (dados.type === "success") {
            alertElement.className =
                "alert flex items-center p-4 mb-4 text-sm text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400 border border-green-200 dark:border-green-800"
            alertElement.innerHTML = `
                <svg class="shrink-0 inline w-4 h-4 me-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z"/>
                </svg>
                <div class="flex-1">
                    <span class="font-medium">Sucesso!</span> ${mensagemSanitizada}
                </div>
                <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-green-50 text-green-500 rounded-lg focus:ring-2 focus:ring-green-400 p-1.5 hover:bg-green-200 inline-flex items-center justify-center h-8 w-8 dark:bg-gray-800 dark:text-green-400 dark:hover:bg-gray-700" aria-label="Fechar alerta">
                    <span class="sr-only">Fechar</span>
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                    </svg>
                </button>
            `
        }

        const closeButton = alertElement.querySelector("button")
        if (closeButton) {
            closeButton.addEventListener("click", () => this.limparAlerta(alertElement))
        }

        this.activeAlerts.add(alertElement)

        const timeoutId = setTimeout(() => {
            this.limparAlerta(alertElement)
        }, 4000)

        alertElement.dataset.timeoutId = timeoutId
    }

    limparAlerta(alertElement) {
        if (!alertElement) return

        if (alertElement.dataset.timeoutId) {
            clearTimeout(alertElement.dataset.timeoutId)
            delete alertElement.dataset.timeoutId
        }

        alertElement.className = "alert hidden"
        alertElement.innerHTML = ""
        alertElement.removeAttribute("role")
        alertElement.removeAttribute("aria-live")

        this.activeAlerts.delete(alertElement)
    }

    limparTodos() {
        this.activeAlerts.forEach((alert) => this.limparAlerta(alert))
    }
}
