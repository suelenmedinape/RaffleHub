import { ParticipantesService } from "../service/ParticipantesService.js"
import { Alert } from "./alert.js"
import { Loading } from "./loading.js"

export class Participantes {
    constructor(checkbox = null) {
        this.participanteService = new ParticipantesService()
        this.alert = new Alert()
        this.loading = new Loading()
        this.checkbox = checkbox
    }

    carregarParticipantes(participantes, qdt) {
        const container = document.querySelector("#participants-list-container")
        if (!container) {
            console.error("Container de participantes não encontrado")
            return
        }

        container.innerHTML = ""

        if (!participantes || participantes.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8">
                    <p class="text-gray-500 dark:text-gray-400">Nenhum participante encontrado</p>
                </div>
            `
            return
        }

        participantes.forEach((participante) => {
            const { id, nomeParticipante, telefone, numerosEscolhidos = [] } = participante

            const participanteDiv = document.createElement("div")
            participanteDiv.className = "mb-6 p-4 border border-gray-200 rounded-lg dark:border-gray-600"
            participanteDiv.id = `participante-item-id-${id}`

            participanteDiv.innerHTML = `
                <div class="alert hidden" id="alert-participante-${id}"></div>
                <div class="flex justify-between items-center mb-3">
                    <div>
                        <h4 class="text-lg font-semibold text-gray-900 dark:text-white">${nomeParticipante || "Nome não informado"}</h4>
                        <p class="text-sm text-gray-500 dark:text-gray-400">${telefone || "Telefone não informado"}</p>
                    </div>
                    <button type="button" class="text-red-600 hover:text-red-800 font-medium text-sm remover-participante-btn" data-id="${id}">
                        Remover Participante
                    </button>
                </div>
                <div class="mb-3">
                    <p class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Números atuais: ${numerosEscolhidos.join(", ") || "Nenhum número selecionado"}
                    </p>
                </div>
                <div id="numeros-participante-id-${id}" class="grid grid-cols-10 gap-2 mb-4"></div>
                <button type="button" id="btn-editar-participante-${id}" 
                  class="w-70 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium salvar-numeros-btn flex items-center justify-center gap-2" data-id="${id}">
                    <div class="btn-spinner hidden animate-spin rounded-full h-4 w-4 border-b-2 border-white" aria-hidden="true"></div>
                    <span class="btn-text">Editar Números</span>
                </button>
            `

            container.appendChild(participanteDiv)
            this.gerarNumerosParaParticipante(id, numerosEscolhidos, qdt, participantes)
        })

        this.adicionarEventListeners(participantes, qdt)
    }

    gerarNumerosParaParticipante(participanteId, numerosAtuais, totalNumeros, todosParticipantes) {
        const container = document.querySelector(`#numeros-participante-id-${participanteId}`)
        if (!container) return

        const numerosOcupados = todosParticipantes
            .filter(p => p.id !== participanteId)
            .flatMap(p => p.numerosEscolhidos || [])

        container.innerHTML = ""

        for (let i = 1; i <= totalNumeros; i++) {
            const isDoParticipante = numerosAtuais.includes(i)
            const isOcupado = numerosOcupados.includes(i)

            const item = document.createElement("div")
            item.innerHTML = `
                <input type="checkbox" id="edit-option-${participanteId}-${i}" value="${i}" class="hidden peer" ${isDoParticipante ? "checked" : ""} ${isOcupado ? "disabled" : ""}>
                <label for="edit-option-${participanteId}-${i}" class="flex items-center justify-center w-10 h-10 text-sm font-semibold rounded-lg cursor-pointer
                    ${isOcupado
                ? "bg-red-100 border-red-300 text-red-600 cursor-not-allowed"
                : "text-gray-500 bg-white border-2 border-gray-200 peer-checked:border-green-600 peer-checked:text-green-600 hover:text-gray-600 hover:bg-gray-50"
            }">
                    ${i}
                </label>
            `
            container.appendChild(item)
        }
    }

    adicionarEventListeners(participantes, qdt) {
        document.querySelectorAll(".remover-participante-btn").forEach((btn) => {
            btn.addEventListener("click", async (e) => {
                const id = e.target.dataset.id
                await this.removerParticipante(id)
            })
        })

        document.querySelectorAll(".salvar-numeros-btn").forEach((btn) => {
            btn.addEventListener("click", async (e) => {
                const id = Number(e.currentTarget.dataset.id)
                const participante = participantes.find((p) => p.id === id)
                if (participante) {
                    await this.salvarNumerosParticipante(id, participante)
                } else {
                    console.warn("Participante não encontrado para ID:", id)
                }
            })
        })
    }

    async removerParticipante(id) {
        const alertContainer = document.querySelector(`#alert-participante-${id}`)

        if (confirm("Tem certeza que deseja remover este participante?")) {
            try {
                const { response } = await this.participanteService.removerParticipante(id)

                if (response.ok) {
                    this.alert.gerarAlerta({ mensagem: "Participante removido com sucesso", type: "success" }, alertContainer)

                    const participanteItem = document.querySelector(`#participante-item-id-${id}`)
                    if (participanteItem) {
                        participanteItem.remove()
                    }

                    if (this.checkbox?.atualizarCheckboxes) {
                        await this.checkbox.atualizarCheckboxes()
                    }
                } else {
                    this.alert.gerarAlerta({ mensagem: "Erro ao remover participante", type: "error" }, alertContainer)
                }
            } catch (error) {
                this.alert.gerarAlerta(
                    { mensagem: `Erro ao remover participante: ${error?.message || JSON.stringify(error)}`, type: "error" },
                    alertContainer,
                )
            }
        }
    }

    async salvarNumerosParticipante(id, participante) {
        const containerId = `#numeros-participante-id-${id}`
        const checkboxes = document.querySelectorAll(`${containerId} input[type="checkbox"]:checked`)
        const numerosSelecionados = Array.from(checkboxes).map(cb => Number(cb.value))
        const alertEl = document.querySelector(`#alert-participante-${id}`)

        this.loading.showButtonLoading(`#btn-editar-participante-${id}`)

        try {
            const dados = {
                id,
                nomeParticipante: participante.nomeParticipante,
                telefone: participante.telefone,
                numerosEscolhidos: numerosSelecionados,
                rifaId: participante.rifaId
            }

            const { response } = await this.participanteService.editarParticipante(id, dados)

            if (response.ok) {
                this.alert.gerarAlerta({ mensagem: "Números atualizados com sucesso", type: "success" }, alertEl)

                if (this.checkbox?.atualizarCheckboxes) {
                    await this.checkbox.atualizarCheckboxes()
                }
            } else {
                this.alert.gerarAlerta({ mensagem: "Erro ao atualizar números", type: "error" }, alertEl)
            }
        } catch (error) {
            this.alert.gerarAlerta(
                { mensagem: `Erro ao atualizar números: ${error?.message || JSON.stringify(error)}`, type: "error" },
                alertEl,
            )
        } finally {
            this.loading.hideButtonLoading(`#btn-editar-participante-${id}`)
        }
    }
}