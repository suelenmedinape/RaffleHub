import { DropdownController } from "../controller/dropdownController.js"
import { RifasService } from "../service/RifasService.js"

export class DropdownLista {

    constructor() {
        this.rifaService = new RifasService()
        this.dropdownController = new DropdownController()
    }

    async listaRifasDisponiveis() {
        const _rifasDisponiveis = document.querySelector("#ul-lista-rifas")
        const { response, responseData } = await this.rifaService.listarRifas()
        const $rifas = responseData.map(rifa => rifa.nomeRifa)
        _rifasDisponiveis.innerHTML = responseData.length === 0
            ? `<li class="px-4 py-2">Nenhuma rifa encontrada</li>`
            : responseData.map(rifa => `
        <li 
          data-nome="${rifa.nomeRifa}" 
          data-id="${rifa.id}" 
          class="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white cursor-pointer">
          ${rifa.nomeRifa}
        </li>`
            ).join("")

        document.querySelectorAll("#ul-lista-rifas li[data-nome]").forEach(li => {
            this.dropdownController.eventoClick(li)
        })
    }
}