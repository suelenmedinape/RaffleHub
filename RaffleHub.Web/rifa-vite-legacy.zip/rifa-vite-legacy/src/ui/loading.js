export class Loading {
    constructor() {
        this.globalLoading = document.querySelector("#global-loading")
        this.activeLoadings = new Set()
    }

    showGlobalLoading() {
        if (this.globalLoading) {
            this.globalLoading.classList.remove("hidden")
            // Melhor acessibilidade
            this.globalLoading.setAttribute("aria-hidden", "false")
            document.body.style.overflow = "hidden" // Prevenir scroll
        }
    }

    hideGlobalLoading() {
        if (this.globalLoading) {
            this.globalLoading.classList.add("hidden")
            this.globalLoading.setAttribute("aria-hidden", "true")
            document.body.style.overflow = "" // Restaurar scroll
        }
    }

    showButtonLoading(buttonId) {
        const button = document.querySelector(buttonId)
        if (!button) return null

        const btnText = button.querySelector(".btn-text")
        const btnSpinner = button.querySelector(".btn-spinner")

        if (btnText && btnSpinner) {
            if (!button.dataset.originalText) {
                button.dataset.originalText = btnText.textContent
            }

            btnText.textContent = "Carregando..."
            btnSpinner.classList.remove("hidden")
            button.disabled = true
            button.classList.add("opacity-75", "cursor-not-allowed")
            button.setAttribute("aria-busy", "true")

            this.activeLoadings.add(button)
        }

        return button
    }

    hideButtonLoading(buttonId) {
        const button = document.querySelector(buttonId)
        if (!button) return

        const btnText = button.querySelector(".btn-text")
        const btnSpinner = button.querySelector(".btn-spinner")

        if (btnText && btnSpinner) {
            btnText.textContent = button.dataset.originalText || "Enviar"
            btnSpinner.classList.add("hidden")
            button.disabled = false
            button.classList.remove("opacity-75", "cursor-not-allowed")
            button.setAttribute("aria-busy", "false")

            this.activeLoadings.delete(button)
        }
    }

    createInlineSpinner(size = "w-4 h-4") {
        const spinner = document.createElement("div")
        spinner.className = `animate-spin rounded-full ${size} border-b-2 border-purple-600`
        spinner.setAttribute("aria-hidden", "true")
        return spinner
    }

    showContainerLoading(containerId, message = "Carregando...") {
        const container = document.querySelector(containerId)
        if (!container) return

        if (!container.dataset.originalContent) {
            container.dataset.originalContent = container.innerHTML
        }

        container.innerHTML = `
            <div class="flex flex-col items-center justify-center py-8 space-y-4" role="status" aria-live="polite">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600" aria-hidden="true"></div>
                <p class="text-gray-600 dark:text-gray-400">${message}</p>
            </div>
        `

        this.activeLoadings.add(container)
    }

    hideContainerLoading(containerId) {
        const container = document.querySelector(containerId)
        if (!container) return

        if (container.dataset.originalContent) {
            container.innerHTML = container.dataset.originalContent
            delete container.dataset.originalContent
        }

        this.activeLoadings.delete(container)
    }

    clearAll() {
        this.activeLoadings.forEach((element) => {
            if (element.tagName === "BUTTON") {
                this.hideButtonLoading(`#${element.id}`)
            } else {
                this.hideContainerLoading(`#${element.id}`)
            }
        })
        this.activeLoadings.clear()
    }
}
