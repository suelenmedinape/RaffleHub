export function debounce(func, wait) {
    let timeout
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout)
            func(...args)
        }
        clearTimeout(timeout)
        timeout = setTimeout(later, wait)
    }
}

export function sanitizeHTML(str) {
    const temp = document.createElement("div")
    temp.textContent = str
    return temp.innerHTML
}

export function formatDateToBR(dateStr) {
    if (!dateStr) return ""
    try {
        const [ano, mes, dia] = dateStr.split("-")
        return `${dia}/${mes}/${ano}`
    } catch (error) {
        console.warn("Error formatting date:", error)
        return dateStr
    }
}

export function formatDateToISO(dateBr) {
    if (!dateBr) return ""
    try {
        const [dia, mes, ano] = dateBr.split("/")
        return `${ano}-${mes}-${dia}`
    } catch (error) {
        console.warn("Error formatting date:", error)
        return dateBr
    }
}

export function validatePhone(phone) {
    const phoneRegex = /^$$\d{2}$$\d{8,9}$/
    return phoneRegex.test(phone)
}

export class TimeoutManager {
    constructor() {
        this.timeouts = new Set()
    }

    setTimeout(callback, delay) {
        const timeoutId = setTimeout(() => {
            this.timeouts.delete(timeoutId)
            callback()
        }, delay)
        this.timeouts.add(timeoutId)
        return timeoutId
    }

    clearTimeout(timeoutId) {
        clearTimeout(timeoutId)
        this.timeouts.delete(timeoutId)
    }

    clearAll() {
        this.timeouts.forEach((id) => clearTimeout(id))
        this.timeouts.clear()
    }
}
