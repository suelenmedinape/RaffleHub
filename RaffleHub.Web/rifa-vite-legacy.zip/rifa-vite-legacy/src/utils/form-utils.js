export class FormUtils {
    static limparFormulario(formSelector) {
        const form = document.querySelector(formSelector)
        if (!form) {
            console.warn(`Formulário ${formSelector} não encontrado`)
            return
        }

        // Limpar todos os inputs de texto, email, tel, number, etc.
        const inputs = form.querySelectorAll(
            'input[type="text"], input[type="email"], input[type="tel"], input[type="number"], input[type="password"]',
        )
        inputs.forEach((input) => {
            input.value = ""
            // Restaurar placeholder original se existir
            if (input.dataset.originalPlaceholder) {
                input.placeholder = input.dataset.originalPlaceholder
            }
        })

        // Limpar textareas
        const textareas = form.querySelectorAll("textarea")
        textareas.forEach((textarea) => {
            textarea.value = ""
        })

        // Limpar selects
        const selects = form.querySelectorAll("select")
        selects.forEach((select) => {
            select.selectedIndex = 0
        })

        // Limpar checkboxes e radios
        const checkboxesRadios = form.querySelectorAll('input[type="checkbox"], input[type="radio"]')
        checkboxesRadios.forEach((input) => {
            input.checked = false
        })

        // Limpar campos de data (datepicker)
        const dateInputs = form.querySelectorAll("input[datepicker]")
        dateInputs.forEach((input) => {
            input.value = ""
            // Se houver instância do datepicker, limpar também
            if (input.datepicker) {
                input.datepicker.clear()
            }
        })

        // Remover classes de erro
        const errorElements = form.querySelectorAll(".text-red-600, .border-red-500")
        errorElements.forEach((element) => {
            if (element.classList.contains("text-red-600")) {
                element.classList.add("hidden")
            }
            if (element.classList.contains("border-red-500")) {
                element.classList.remove("border-red-500")
                element.classList.add("border-gray-300")
            }
        })

        // Limpar mensagens de erro
        const errorMessages = form.querySelectorAll('[id$="-error"]')
        errorMessages.forEach((error) => {
            error.classList.add("hidden")
            error.textContent = ""
        })

        console.log(`Formulário ${formSelector} limpo com sucesso`)
    }

    static limparCamposEspecificos(campos) {
        campos.forEach((seletor) => {
            const elemento = document.querySelector(seletor)
            if (elemento) {
                if (elemento.type === "checkbox" || elemento.type === "radio") {
                    elemento.checked = false
                } else {
                    elemento.value = ""
                }
            }
        })
    }
}
